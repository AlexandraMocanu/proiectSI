#include "ball.h"
#include "globals.h"

Ball::Ball(){
    this -> x = width / 2;
    this -> y = height * 3 / 4;
    this -> e = 1;
    this -> r = 5;
    this -> vx = game_speed;
    this -> ball_speed = game_speed;
    this -> vy = this -> ball_speed;
    this -> add_vx = 0.2;
    this -> mybox = box;
}    
 
void Ball::move(){
    this -> x = this -> x + this -> vx;
    this -> y = this -> y + this -> vy;

    // left of screen
    if(this -> x < (r/3 + offsetX + 1)) {
        this -> vx = -e*this -> vx;
        this -> x = r/3 + offsetX + 1;
    }

    // right of screen
    if(this -> x > (width - r/3 - offsetX - 1)){
        this -> vx = -e*this -> vx;
        this -> x = width - r/3 - offsetX - 1;
    }

    //Bottom - you died son
    if(this -> y > height - r/3){
        life_count -= 1;
        this -> x = width / 2;
        this -> y = height * 3 / 4;
        this -> vx = ball_speed;
        this -> vy = ball_speed;   
    }

    // top of screen
    if(this -> y < (r/3 + offsetY + 1 )){
        this -> vy = -e*this -> vy;
        this -> y = r/3 + offsetY + 1 ;  
    }

    //bar impact
    float bar_distance = this->x - (bar_x + bar_l / 2);

    bar_distance = abs(bar_distance);
    if ( bar_distance < (bar_l / 2 + r)) { //if on bar
        if ( this->y > (bar_y - r) ) { //if low enough 
            this -> y = bar_y - this -> r;
            this -> vy = - (this -> vy);
            this -> vx = this -> vx + ( this -> add_vx * bar_dx );
            // if (bar_distance > 0) { // from the right
            //     // this -> vx -= bar_v * this -> add_vx;
            //     // this -> vy = sqrt(sq(this -> ball_speed) - sq(this -> vx));
            // } else if (bar_distance < 0) { // from the left
            //     // this -> vx += bar_v * this -> add_vx;
            //     // this -> vy = -sqrt(sq(this -> ball_speed) - sq(this -> vx));
            // } else { // falls directly on it
            //     this -> vy *= -e;
            // }
        }
    }

    //boxes impact
    int box_distance;
    int y_distance;
    for (int i = 0; i < box_count; ++i) {
        if (box[i] -> dead)
            continue;
        //from below box
        box_distance = abs(this -> x - (box[i] -> x + box[i] -> l / 2));
        if ( box_distance < (box[i] -> l / 2 + r / 2)) { // ball has same x as box
            y_distance = this -> y - (box[i] -> y + (box[i] -> t / 2));
            //check if close enough, if yes -> we got a hit
            if ( abs(y_distance) <= (box[i] -> t / 2 + r)) {
                box[i] -> hit();
                // from below
                if (y_distance <= (box[i] -> t / 2 + r + 1) && abs(y_distance) > (box[i] -> t / 2)) {
                    this -> vy = -e * this->vy;
                }
                //from above
                else if ( y_distance >= (box[i] -> t / 2 - r - 1) && abs(y_distance) > (box[i] -> t / 2)) {
                    this -> vy = -e * this->vy;
                }
                // from aside
                else if ( abs(y_distance) <= (box[i] -> t / 2)) {
                    this -> vx = -e *  this -> vx;
                }
            }
        } 
    }

    //bar impact
    // float bar_x_range = this -> x - bar_x;
    // d_x = bar_x - p_x;
    // if((bar_x_range > bar_l + r/2) && (bar_x_range < -r/2) && (this -> vy > 0))
    // {
    //     if(((this -> y - bar_y) < 0) && ((bar_y - this -> y) < (this -> r/3))){
    //         this -> y = bar_y - this -> r/3;
                
    //         if(d_x < 0){
    //             this -> vx -= bar_v * this -> add_vx;
    //             this -> vy = -sqrt(sq(this -> ball_speed) - sq(this -> vx));
    //         }
            
    //         else if(d_x > 0){
    //             this -> vx += bar_v * this -> add_vx;
    //             this -> vy = -sqrt(sq(this -> ball_speed) - sq(this -> vx));
    //         }
            
    //         else
    //         this -> vy = -e*this -> vy;
    //     }
    // } 
    // Serial.println("second");
    // //box impact
    // float side_impact = this -> r/3;
    // float* box_x_range = new float[box_count];
    // float* box_y_range = new float[box_count];
    // float corner_impact = r/3;
        
    // for(int i = 0; i < box_count; i++){
    //     box_x_range[i] = this -> x - this -> mybox[i] -> x;
    //     box_y_range[i] = this -> y - this -> mybox[i] -> y;
        
    // }

    // Serial.println("third");
    // //upper side
    // for(int i = 0; i < box_count; i++){
        
    // if((box_x_range[i] < this -> mybox[i] -> l) && (box_x_range[i] > 0) && (this -> vy > 0))
    // {
    //     if(((this -> y - this -> mybox[i] -> y) < 0) && ((this -> mybox[i] -> y - this -> y) < (side_impact))){
    //         this -> y = this -> mybox[i] -> y - side_impact;
    //         this -> vy = -e*this -> vy;
    //         this -> mybox[i] -> contact += 1;
    //     }
    // }

    // Serial.println("4");
    // //left side
    // if((box_y_range[i] < this -> mybox[i] -> t) && (box_y_range[i] > 0) && (this -> vx > 0))
    // {
    //     if(((this -> x - this -> mybox[i] -> x) < 0) && ((this -> mybox[i] -> x - this -> x) < (side_impact))){
    //         this -> x = this -> mybox[i] -> x - side_impact;
    //         this -> vx = -e*this -> vx;
    //         this -> mybox[i] -> contact += 1;
    //     }
    // }
    // Serial.println("5");
    // //bottom side
    // if((box_x_range[i] < this -> mybox[i] -> l) && (box_x_range[i] > 0) && (this -> vy < 0))
    // {
    //     if(((this -> y - (this -> mybox[i] -> y + this -> mybox[i] -> t)) > 0) && ((this -> y - (this -> mybox[i] -> y + this -> mybox[i] -> t)) < (side_impact))){
    //         this -> y = this -> mybox[i] -> y + this -> mybox[i] -> t + side_impact;
    //         this -> vy = -e*this -> vy;
    //         this -> mybox[i] -> contact += 1;
    //     }
    // }
    // Serial.println("6");
    // //right side
    // if((box_y_range[i] < this -> mybox[i] -> t) && (box_y_range[i] > 0) && (this -> vx < 0))
    // {
    //     if(((this -> x - (this -> mybox[i] -> x + this -> mybox[i] -> l)) > 0) && ((this -> x - (this -> mybox[i] -> x + this -> mybox[i] -> l)) < (side_impact))){
    //         this -> x = this -> mybox[i] -> x + this -> mybox[i] -> l + side_impact;
    //         this -> vx = -e*this -> vx;
    //         this -> mybox[i] -> contact += 1;
    //     }
    // }
    // Serial.println("7");
    // //corner
    // if((this -> x < this -> mybox[i] -> x) && (this -> mybox[i] -> x - this -> x < corner_impact) && (this -> y < this -> mybox[i] -> y) && (this -> mybox[i] -> y - this -> y < corner_impact)){
    //     this -> x = this -> mybox[i] -> x - corner_impact;
    //     this -> y = this -> mybox[i] -> y - corner_impact;
    //     swap(this -> vx, this -> vy);
    //     this -> mybox[i] -> contact += 1;
    // }
    // if((this -> x < this -> mybox[i] -> x) && (this -> mybox[i] -> x - this -> x < corner_impact) && (this -> y > this -> mybox[i] -> y + this -> mybox[i] -> t) && (this -> y - (this -> mybox[i] -> y + this -> mybox[i] -> t) < corner_impact)){
    //     this -> x = this -> mybox[i] -> x - corner_impact;
    //     this -> y = this -> mybox[i] -> y + this -> mybox[i] -> t + corner_impact;
    //     swap(this -> vx, this -> vy);
    //     this -> mybox[i] -> contact += 1;
    // }
    // if((this -> x > this -> mybox[i] -> x + this -> mybox[i] -> l) && (this -> x - (this -> mybox[i] -> x + this -> mybox[i] -> l)< corner_impact) && (this -> y < this -> mybox[i] -> y) && (this -> mybox[i] -> y - this -> y < corner_impact)){
    //     this -> x = this -> mybox[i] -> x + this -> mybox[i] -> l + corner_impact;
    //     this -> y = this -> mybox[i] -> y - corner_impact;
    //     swap(this -> vx, this -> vy);
    //     this -> mybox[i] -> contact += 1;
    // }
    // if((this -> x > this -> mybox[i] -> x + this -> mybox[i] -> l) && (this -> x - (this -> mybox[i] -> x + this -> mybox[i] -> l) < corner_impact) && (this -> y > this -> mybox[i] -> y + this -> mybox[i] -> t) && (this -> y - (this -> mybox[i] -> y + this -> mybox[i] -> t) < corner_impact)){
    //     this -> x = this -> mybox[i] -> x + this -> mybox[i] -> l + corner_impact;
    //     this -> y = this -> mybox[i] -> y + this -> mybox[i] -> t + corner_impact;
    //     swap(this -> vx, this -> vy);
    //     this -> mybox[i] -> contact += 1;
    // }
    // }
    // Serial.println("finish");
}
  
// void Ball::swap(float x, float y){
//     float temp = 0;
//     temp = x;
//     x = y;
//     y = temp;
// }

void Ball::draw(Adafruit_TFTLCD &tft){ 
    tft.fillCircle(this -> x, this -> y, this -> r, WHITE);
    // fill(255);
    // ellipse(this -> x, this -> y, this -> r, this -> r);
}