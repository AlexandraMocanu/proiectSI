#include "block.h"
#include "globals.h"

Block::Block() {
    this->x = 0;
    this->y = 0;
    this->contact = 0;
    this->interval = 1;
    this->l = (width - 2*offsetX) / box_column;
    this->t = (height - offsetY) / 3 / box_row;
    this->needsRedraw = true;
    this->dead=false;
}

void Block::draw(Adafruit_TFTLCD &tft) {
     if(this->contact == 0)
      this->color = MAGENTA;
    else if(this->contact == 1)
      this->color = BLUE;
    else if(this->contact == 2)
      this->color = GREEN;

    tft.fillRect(this->x + this->interval, this->y + this->interval, this->l - 2*this->interval, this->t - 2*this->interval, this->color);
    // tft.drawRect(this->x + this->interval, this->y + this->interval, this->l - 2*this->interval, this->t - 2*this->interval, this->color);
    if(this->contact > 2){
      tft.fillRect(this->x + this->interval, this->y + this->interval, this->l - 2*this->interval, this->t - 2*this->interval, BLACK);
      this->dead = true;
      return;
    }
    this -> needsRedraw = false;
  }

void Block::hit() {
  this -> contact++;
  this -> needsRedraw = true;
}