#ifndef BALL_H
#define BALL_H

#include <SPFD5408_Adafruit_GFX.h>    // Core graphics library
#include <SPFD5408_Adafruit_TFTLCD.h> // Hardware-specific library
#include "block.h"

class Ball {
  public:
    float x, y, e, r, vx, vy, box_l, box_t, ball_speed, add_vx;
    Block** mybox;

    Ball();
    void draw(Adafruit_TFTLCD &tft);
    void move();
    // void swap(float x, float y); //TODO: fix this, make it globalsmh
};

#endif /* BALL_H */