#ifndef BLOCK_H
#define BLOCK_H

#include <SPFD5408_Adafruit_GFX.h>    // Core graphics library
#include <SPFD5408_Adafruit_TFTLCD.h> // Hardware-specific library

class Block {
  public:
    float x, y, l, t, contact, interval;
    int index, color;
    bool needsRedraw, dead;

    Block();
    void draw(Adafruit_TFTLCD &tft);
    void hit();
};

#endif /* BLOCK_H */