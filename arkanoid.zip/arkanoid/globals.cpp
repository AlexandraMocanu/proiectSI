#include "globals.h"

extern int set_no = 1;
extern int i = 0;
extern int game_speed = 1;
extern int start_key = 0;
extern int life_count = 3;
extern int p = 0;

extern float p_x = 0;
extern float d_x = 0;

extern float bar_y = 225;
extern float bar_l = 50;
extern float bar_x = 100 - bar_l/2;
extern float bar_t = bar_l/5;
extern float bar_v = 15;
extern float bar_dx = 0;

// Dimensions

extern int width = 0;
extern int height = 0;

extern int offsetX = 10;
extern int offsetY = 15;

extern Ball* ball = nullptr;
extern Block** box = nullptr;

extern int box_row = 5;
extern int box_column = 5;
extern int box_count = box_row * box_column;